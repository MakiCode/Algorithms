import java.util.Arrays;

public class Fast {
  public static void main(String[] args) {
    In in = new In(args[0]);
    int N = in.readInt();
    Point[] a = new Point[N];
    StdDraw.setXscale(0, 32768);
    StdDraw.setYscale(0, 32768);
    for (int i = 0; i < N; i++) {
      int x = in.readInt();
      int y = in.readInt();
      Point point = new Point(x, y);
      point.draw();
      a[i] = point;
    }
    
    for (int j = 0; j < a.length; j++) {
      Point point = a[j];
      Arrays.sort(a, j, a.length, point.SLOPE_ORDER);

      for (int k = j; k < a.length; k++) { // go from a[j] to end
        if (a.length - k <= 3) {
          break;
        }
        if (point.slopeTo(a[k]) == point.slopeTo(a[k + 1])
            && point.slopeTo(a[k]) == point.slopeTo(a[k + 2])) {
          // check on each side whether we have a match
          Point[] tmp = new Point[4];
          tmp[0] = a[k];
          tmp[1] = a[k + 1];
          tmp[2] = a[k + 2];
          tmp[3] = point;
          Arrays.sort(tmp);
          tmp[0].drawTo(tmp[3]);
          StdOut.println(tmp[0]+" -> "+tmp[1]+" -> "+tmp[2]+" -> "+tmp[3]);
        }
      }
    }
  }
}